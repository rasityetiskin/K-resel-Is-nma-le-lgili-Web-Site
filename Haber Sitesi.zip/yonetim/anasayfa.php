<div class="templatemo-content col-1 light-gray-bg">
        <div class="templatemo-content-container">
          <div class="templatemo-flex-row flex-content-row">
            <div class="templatemo-content-widget white-bg col-2">
              <i class="fa fa-times"></i>
              <div class="square"></div>
              <h2 class="templatemo-inline-block">Haberler Admin Panel</h2><hr>
              <p>
                Sitemizin Yönetimini admin panelden yapabilirsiniz
              </p>
            </div>
          </div>
          <!-- Second row ends -->
          <footer class="text-right">
            <p>Copyright © Web Site Ödevim Raşit Yetişkin Tüm Hakları Saklıdır 2022</p>
          </footer>         
        </div>
      </div>